# Client Analysis Summary: John Doe

## Client Overview
- **Name:** John Doe
- **Email:** john.doe@test.com
- **Phone:** null
- **Date of Birth:** Not provided
- **Gender:** Not specified
- **Commercial Driver:** Yes
- **Status:** SIGNED_UP
- **Last Visit:** No previous visits

## Health Goals
No health goals specified

## Current Medications
No medications listed

## Medical Conditions
No conditions listed

## Allergies
No allergies listed

## Assessment Summary
- **Total Assessments:** 1

### Assessment (Mon Aug 25 2025 03:00:00 GMT-0700 (Pacific Daylight Time))
- **Status:** completed
- **Total Questions:** 5
- **Average Score:** 4.2/5.0
- **Completed:** 8/25/2025


## Document Summary
- **Total Documents:** 3

### NAQ-Questions-Answers.pdf
- **Type:** UNKNOWN 
- **Uploaded:** 8/26/2025
- **Analysis Status:** PENDING
- **Lab Values:** 0 values extracted


### Symptom-Burden-Bar-Graph (1).pdf
- **Type:** UNKNOWN 
- **Uploaded:** 8/26/2025
- **Analysis Status:** PENDING
- **Lab Values:** 0 values extracted


### Symptom-Burden-Report.pdf
- **Type:** UNKNOWN 
- **Uploaded:** 8/26/2025
- **Analysis Status:** PENDING
- **Lab Values:** 0 values extracted



## Clinical Notes Summary
- **Total Notes:** 2

### COACHING Note - 8/26/2025
**Title:** 2-Week Follow-up Coaching Session

**Next Steps:** Adjust meal prep strategies, introduce portable healthy snacks
**⚠️ Follow-up Required**

### INTERVIEW Note - 8/25/2025
**Title:** Initial Functional Medicine Assessment
**Chief Complaints:** Chronic fatigue, digestive issues, afternoon energy crashes
**Next Steps:** Start with digestive support protocol, stress management techniques, and sleep hygiene improvements
**⚠️ Follow-up Required**


## Treatment Protocols
- **Total Protocols:** 1

### Digestive Health & Energy Optimization Protocol
- **Status:** active
- **Created:** 8/25/2025
- **Supplements:** 1 items
- **Dietary Guidelines:** 3 items
- **Lifestyle Changes:** 3 items


## Export Information
- **Exported On:** 8/27/2025
- **Export Version:** 1.0.0
- **Data Completeness:** 7 total records

---
*This summary was automatically generated from the FNTP assessment system.*
